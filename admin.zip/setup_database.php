<?php
// Simple database setup script for 24 X 7 News Portal
echo "<h2>24 X 7 News Portal - Database Setup</h2>";

// Database connection parameters - try different configurations
$configs = [
    ['host' => 'localhost', 'user' => 'root', 'pass' => ''],
    ['host' => 'localhost', 'user' => 'root', 'pass' => 'root'],
    ['host' => 'localhost', 'user' => 'root', 'pass' => 'mysql'],
    ['host' => '127.0.0.1', 'user' => 'root', 'pass' => ''],
    ['host' => 'localhost:3306', 'user' => 'root', 'pass' => '']
];

$conn = null;
$working_config = null;

echo "<p>🔍 Trying different MySQL connection configurations...</p>";

foreach ($configs as $config) {
    try {
        echo "<p>Trying: {$config['user']}@{$config['host']} with password: " . ($config['pass'] ? 'YES' : 'NO') . "</p>";
        
        $conn = new mysqli($config['host'], $config['user'], $config['pass']);
        
        if (!$conn->connect_error) {
            echo "<p style='color: green;'>✅ Connected successfully with {$config['user']}@{$config['host']}!</p>";
            $working_config = $config;
            break;
        } else {
            echo "<p style='color: orange;'>⚠️ Failed: " . $conn->connect_error . "</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ Exception: " . $e->getMessage() . "</p>";
    }
}

if (!$conn || $conn->connect_error) {
    echo "<div style='background: #ffebee; padding: 20px; border-left: 4px solid #f44336; margin: 20px 0;'>";
    echo "<h3>❌ MySQL Connection Failed</h3>";
    echo "<p><strong>Manual Fix Required:</strong></p>";
    echo "<ol>";
    echo "<li>Open XAMPP Control Panel</li>";
    echo "<li>Stop MySQL service</li>";
    echo "<li>Click 'Config' next to MySQL → 'my.ini'</li>";
    echo "<li>Find <code>[mysqld]</code> section and add: <code>skip-grant-tables</code></li>";
    echo "<li>Save file and restart MySQL</li>";
    echo "<li>Refresh this page</li>";
    echo "</ol>";
    echo "<p><strong>Alternative:</strong> Use XAMPP Shell and run: <code>mysql -u root</code></p>";
    echo "</div>";
    exit;
}

try {
    
    // Check connection
    if ($conn->connect_error) {
        die("<p style='color: red;'>Connection failed: " . $conn->connect_error . "</p>");
    }
    echo "<p style='color: green;'>✅ Connected to MySQL successfully!</p>";
    
    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS newsportal";
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green;'>✅ Database 'newsportal' created successfully!</p>";
    } else {
        echo "<p style='color: red;'>❌ Error creating database: " . $conn->error . "</p>";
    }
    
    // Select the database
    $conn->select_db("newsportal");
    
    // Create basic tables (simplified version)
    $tables = [
        "CREATE TABLE IF NOT EXISTS tblcategory (
            id int(11) NOT NULL AUTO_INCREMENT,
            CategoryName varchar(200) DEFAULT NULL,
            Description mediumtext DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT 1,
            PRIMARY KEY (id)
        )",
        
        "CREATE TABLE IF NOT EXISTS tblposts (
            id int(11) NOT NULL AUTO_INCREMENT,
            PostTitle longtext DEFAULT NULL,
            CategoryId int(11) DEFAULT NULL,
            PostDetails longtext DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT 1,
            PostUrl mediumtext DEFAULT NULL,
            PostImage varchar(255) DEFAULT NULL,
            viewCounter int(11) DEFAULT 0,
            PRIMARY KEY (id)
        )",
        
        "CREATE TABLE IF NOT EXISTS tbladmin (
            id int(11) NOT NULL AUTO_INCREMENT,
            AdminUserName varchar(255) DEFAULT NULL,
            AdminPassword varchar(255) DEFAULT NULL,
            AdminEmailId varchar(255) DEFAULT NULL,
            userType int(11) DEFAULT 1,
            CreationDate timestamp NOT NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            PRIMARY KEY (id)
        )"
    ];
    
    foreach ($tables as $sql) {
        if ($conn->query($sql) === TRUE) {
            echo "<p style='color: green;'>✅ Table created successfully!</p>";
        } else {
            echo "<p style='color: red;'>❌ Error creating table: " . $conn->error . "</p>";
        }
    }
    
    // Insert sample data
    $sampleData = [
        "INSERT IGNORE INTO tblcategory (id, CategoryName, Description, Is_Active) VALUES 
        (1, 'Sports', 'Sports news and updates', 1),
        (2, 'Politics', 'Political news and developments', 1),
        (3, 'Entertainment', 'Entertainment and celebrity news', 1),
        (4, 'Business', 'Business and economic news', 1),
        (5, 'Technology', 'Technology and innovation news', 1)",
        
        "INSERT IGNORE INTO tbladmin (id, AdminUserName, AdminPassword, AdminEmailId, userType) VALUES 
        (1, 'admin', 'f925916e2754e5e03f75dd58a5733251', 'admin@24x7news.com', 1)",
        
        "INSERT IGNORE INTO tblposts (id, PostTitle, CategoryId, PostDetails, Is_Active, PostUrl, viewCounter) VALUES 
        (1, 'Welcome to 24 X 7 News Portal', 1, 'This is your first news article. You can edit or delete this from the admin panel.', 1, 'welcome-to-24-x-7-news-portal', 0)"
    ];
    
    foreach ($sampleData as $sql) {
        if ($conn->query($sql) === TRUE) {
            echo "<p style='color: green;'>✅ Sample data inserted!</p>";
        } else {
            echo "<p style='color: orange;'>⚠️ Sample data: " . $conn->error . "</p>";
        }
    }
    
    echo "<h3 style='color: green;'>🎉 Database Setup Complete!</h3>";
    
    // Update the config.php file with working database settings
    if ($working_config) {
        $config_content = "<?php
define('DB_SERVER','{$working_config['host']}');
define('DB_USER','{$working_config['user']}');
define('DB_PASS','{$working_config['pass']}');
define('DB_NAME','newsportal');
\$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno())
{
 echo \"Failed to connect to MySQL: \" . mysqli_connect_error();
}
?>";
        
        if (file_put_contents('includes/config.php', $config_content)) {
            echo "<p style='color: green;'>✅ Database configuration updated in includes/config.php</p>";
        }
    }
    
    echo "<p><strong>Admin Login Details:</strong></p>";
    echo "<ul>";
    echo "<li>Username: <code>admin</code></li>";
    echo "<li>Password: <code>Test@123</code></li>";
    echo "<li>Admin URL: <a href='admin/'>admin/</a></li>";
    echo "</ul>";
    echo "<p><a href='index.php' style='background: #2563eb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>🏠 Go to Homepage</a></p>";
    
    $conn->close();
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>