<?php
// This page uses Bootstrap 5 modern design
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>24 X 7 - Latest News & Updates</title>
    <!-- Preload critical resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" as="style">
    
    <!-- Load stylesheets -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    
    <!-- Scroll Progress Bar Styles -->
    <style>
        .scroll-progress {
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            background: linear-gradient(90deg, #007bff, #0056b3);
            z-index: 9999;
            transition: width 0.1s ease-out;
            box-shadow: 0 2px 4px rgba(0, 123, 255, 0.3);
        }
    </style>
</head>
<body>
<!-- Scroll Progress Bar -->
<div class="scroll-progress" id="scrollProgress"></div>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.php">
      <i class="bi bi-newspaper me-2"></i>24 X 7
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active" href="index.php">
            <i class="bi bi-house me-1"></i>Home
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about-us.php">
            <i class="bi bi-info-circle me-1"></i>About
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact-us.php">
            <i class="bi bi-envelope me-1"></i>Contact
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="category.php">
            <i class="bi bi-grid me-1"></i>Categories
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="search.php">
            <i class="bi bi-search me-1"></i>Search
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<div class="container my-5">
  <div class="row align-items-center mb-5">
    <div class="col-lg-8">
      <h1 class="display-4 fw-bold mb-3">
        <i class="bi bi-lightning-charge text-warning me-2"></i>
        Latest News & Updates
      </h1>
      <p class="lead text-muted">Stay informed with the most recent news, breaking stories, and in-depth analysis from around the world.</p>
    </div>
    <div class="col-lg-4 text-end">
      <div class="d-flex gap-2 justify-content-lg-end justify-content-start">
        <a href="category.php" class="btn btn-outline-primary">
          <i class="bi bi-grid me-1"></i>Browse Categories
        </a>
        <a href="search.php" class="btn btn-primary">
          <i class="bi bi-search me-1"></i>Search News
        </a>
      </div>
    </div>
  </div>

  <!-- Featured News Section -->
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="card featured-card h-100">
        <div class="card-img-top d-flex align-items-center justify-content-center text-white fw-bold" style="height: 300px; background: linear-gradient(45deg, #2563eb, #1d4ed8); font-size: 28px; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">
          <div class="text-center">
            <i class="bi bi-newspaper display-3 mb-3"></i>
            <div>BREAKING NEWS</div>
            <small class="d-block mt-2" style="font-size: 16px;">24 X 7 Coverage</small>
          </div>
        </div>
        <div class="card-body">
          <div class="d-flex align-items-center mb-2">
            <span class="category-badge me-2">Breaking News</span>
            <small class="text-muted">
              <i class="bi bi-clock me-1"></i>2 hours ago
            </small>
          </div>
          <h3 class="card-title">Featured: Major Breaking News Story</h3>
          <p class="card-text">This is a featured news story that provides comprehensive coverage of the most important events happening right now. Get all the details and latest updates here.</p>
          <div class="d-flex justify-content-between align-items-center">
            <a href="news-details.php" class="btn btn-primary">
              <i class="bi bi-arrow-right me-1"></i>Read Full Story
            </a>
            <div class="d-flex gap-2">
              <button class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-heart"></i>
              </button>
              <button class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-share"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="col-lg-4">
      <div class="row g-3">
        <div class="col-12">
          <div class="card h-100">
            <div class="card-img-top d-flex align-items-center justify-content-center text-white fw-bold" style="height: 150px; background: linear-gradient(45deg, #10b981, #059669); font-size: 20px; text-shadow: 1px 1px 3px rgba(0,0,0,0.5);">
              <div class="text-center">
                <i class="bi bi-trophy display-6 mb-2"></i>
                <div>SPORTS</div>
              </div>
            </div>
            <div class="card-body">
              <div class="d-flex align-items-center mb-2">
                <span class="category-badge me-2" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%);">Sports</span>
                <small class="text-muted">
                  <i class="bi bi-clock me-1"></i>4 hours ago
                </small>
              </div>
              <h5 class="card-title">Sports Update: Championship Results</h5>
              <p class="card-text">Latest results from the championship games...</p>
              <a href="news-details.php" class="btn btn-sm btn-outline-primary">Read More</a>
            </div>
          </div>
        </div>
        
        <div class="col-12">
          <div class="card h-100">
            <div class="card-img-top d-flex align-items-center justify-content-center text-white fw-bold" style="height: 150px; background: linear-gradient(45deg, #8b5cf6, #7c3aed); font-size: 20px; text-shadow: 1px 1px 3px rgba(0,0,0,0.5);">
              <div class="text-center">
                <i class="bi bi-cpu display-6 mb-2"></i>
                <div>TECH</div>
              </div>
            </div>
            <div class="card-body">
              <div class="d-flex align-items-center mb-2">
                <span class="category-badge me-2" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);">Technology</span>
                <small class="text-muted">
                  <i class="bi bi-clock me-1"></i>6 hours ago
                </small>
              </div>
              <h5 class="card-title">Tech Innovation: AI Breakthrough</h5>
              <p class="card-text">Revolutionary AI technology announced today...</p>
              <a href="news-details.php" class="btn btn-sm btn-outline-primary">Read More</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Recent News Grid -->
  <div class="row mt-5">
    <div class="col-12">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h3 mb-0">
          <i class="bi bi-newspaper me-2"></i>Recent Articles
        </h2>
        <a href="category.php" class="btn btn-outline-primary btn-sm">
          View All <i class="bi bi-arrow-right ms-1"></i>
        </a>
      </div>
    </div>
  </div>

  <div class="row g-4">
    <div class="col-md-6 col-lg-4">
      <div class="card h-100">
        <div class="card-img-top d-flex align-items-center justify-content-center text-white fw-bold" style="height: 200px; background: linear-gradient(45deg, #ef4444, #dc2626); font-size: 24px; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">
          <div class="text-center">
            <i class="bi bi-bank display-5 mb-2"></i>
            <div>POLITICS</div>
          </div>
        </div>
        <div class="card-body">
          <div class="d-flex align-items-center mb-2">
            <span class="category-badge me-2" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);">Politics</span>
            <small class="text-muted">
              <i class="bi bi-clock me-1"></i>1 day ago
            </small>
          </div>
          <h5 class="card-title">Political Development Story</h5>
          <p class="card-text">Important political news and developments from the capital...</p>
          <a href="news-details.php" class="btn btn-primary btn-sm">
            <i class="bi bi-arrow-right me-1"></i>Read More
          </a>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-4">
      <div class="card h-100">
        <div class="card-img-top d-flex align-items-center justify-content-center text-white fw-bold" style="height: 200px; background: linear-gradient(45deg, #06b6d4, #0891b2); font-size: 24px; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">
          <div class="text-center">
            <i class="bi bi-graph-up display-5 mb-2"></i>
            <div>BUSINESS</div>
          </div>
        </div>
        <div class="card-body">
          <div class="d-flex align-items-center mb-2">
            <span class="category-badge me-2" style="background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%);">Business</span>
            <small class="text-muted">
              <i class="bi bi-clock me-1"></i>2 days ago
            </small>
          </div>
          <h5 class="card-title">Market Analysis Report</h5>
          <p class="card-text">Comprehensive analysis of current market trends and forecasts...</p>
          <a href="news-details.php" class="btn btn-primary btn-sm">
            <i class="bi bi-arrow-right me-1"></i>Read More
          </a>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-4">
      <div class="card h-100">
        <div class="card-img-top d-flex align-items-center justify-content-center text-white fw-bold" style="height: 200px; background: linear-gradient(45deg, #f59e0b, #d97706); font-size: 24px; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">
          <div class="text-center">
            <i class="bi bi-film display-5 mb-2"></i>
            <div>ENTERTAINMENT</div>
          </div>
        </div>
        <div class="card-body">
          <div class="d-flex align-items-center mb-2">
            <span class="category-badge me-2" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">Entertainment</span>
            <small class="text-muted">
              <i class="bi bi-clock me-1"></i>3 days ago
            </small>
          </div>
          <h5 class="card-title">Entertainment Industry News</h5>
          <p class="card-text">Latest updates from the world of entertainment and celebrities...</p>
          <a href="news-details.php" class="btn btn-primary btn-sm">
            <i class="bi bi-arrow-right me-1"></i>Read More
          </a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bottom Social Media Share Section -->
<div class="container my-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-4">
          <h5 class="card-title mb-3">
            <i class="bi bi-share me-2"></i>Share This Page
          </h5>
          <p class="text-muted mb-4">Help others discover the latest news by sharing on social media</p>
          <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="#" class="btn btn-primary d-flex align-items-center" id="bottomShareFacebook" style="background: #1877f2; border-color: #1877f2;">
              <i class="bi bi-facebook me-2"></i>Share on Facebook
            </a>
            <a href="#" class="btn btn-info d-flex align-items-center" id="bottomShareTwitter" style="background: #1da1f2; border-color: #1da1f2;">
              <i class="bi bi-twitter me-2"></i>Share on Twitter
            </a>
            <a href="#" class="btn btn-success d-flex align-items-center" id="bottomShareWhatsApp" style="background: #25d366; border-color: #25d366;">
              <i class="bi bi-whatsapp me-2"></i>Share on WhatsApp
            </a>
            <button class="btn btn-secondary d-flex align-items-center" id="bottomPrintPage">
              <i class="bi bi-printer-fill me-2"></i>Print Page
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="footer mt-5">
  <div class="container">
    <p class="mb-0">&copy; 2025 24 X 7. All rights reserved.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Scroll Progress Bar Script -->
<script>
window.addEventListener('scroll', function() {
    const scrollProgress = document.getElementById('scrollProgress');
    const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrollPercentage = (scrollTop / scrollHeight) * 100;
    
    scrollProgress.style.width = scrollPercentage + '%';
});

// Bottom Social Media Share Functions
document.getElementById('bottomShareFacebook').addEventListener('click', function(e) {
    e.preventDefault();
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank', 'width=600,height=400');
});

document.getElementById('bottomShareTwitter').addEventListener('click', function(e) {
    e.preventDefault();
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    window.open(`https://twitter.com/intent/tweet?url=${url}&text=${title}`, '_blank', 'width=600,height=400');
});

document.getElementById('bottomShareWhatsApp').addEventListener('click', function(e) {
    e.preventDefault();
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    window.open(`https://wa.me/?text=${title} ${url}`, '_blank');
});

document.getElementById('bottomPrintPage').addEventListener('click', function() {
    window.print();
});
</script>
</body>
</html>
