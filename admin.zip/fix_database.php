<?php
// Fix database for 24 X 7 News Portal
echo "<!DOCTYPE html><html><head><title>Fix Database</title>";
echo "<style>body{font-family:Arial,sans-serif;max-width:600px;margin:50px auto;padding:20px;} .success{color:green;} .error{color:red;} .warning{color:orange;}</style>";
echo "</head><body>";
echo "<h1>🔧 Fixing 24 X 7 Database</h1>";

try {
    // Connect to MySQL
    $conn = new mysqli('localhost', 'root', '');
    
    if ($conn->connect_error) {
        die("<p class='error'>❌ Connection failed: " . $conn->connect_error . "</p>");
    }
    
    echo "<p class='success'>✅ Connected to MySQL</p>";
    
    // Drop existing database and recreate
    echo "<p class='warning'>🗑️ Dropping existing database...</p>";
    $conn->query("DROP DATABASE IF EXISTS newsportal");
    
    echo "<p class='success'>✅ Creating fresh database...</p>";
    $sql = "CREATE DATABASE newsportal";
    if ($conn->query($sql) === TRUE) {
        echo "<p class='success'>✅ Database 'newsportal' created successfully</p>";
    } else {
        die("<p class='error'>❌ Error creating database: " . $conn->error . "</p>");
    }
    
    // Select database
    $conn->select_db("newsportal");
    
    // Create all required tables
    echo "<h3>📋 Creating Tables...</h3>";
    
    $tables = [
        "tblcategory" => "CREATE TABLE tblcategory (
            id int(11) NOT NULL AUTO_INCREMENT,
            CategoryName varchar(200) DEFAULT NULL,
            Description mediumtext DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT NULL,
            PRIMARY KEY (id)
        )",
        
        "tblsubcategory" => "CREATE TABLE tblsubcategory (
            SubCategoryId int(11) NOT NULL AUTO_INCREMENT,
            CategoryId int(11) DEFAULT NULL,
            Subcategory varchar(255) DEFAULT NULL,
            SubCatDescription mediumtext DEFAULT NULL,
            PostingDate timestamp NOT NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT NULL,
            PRIMARY KEY (SubCategoryId),
            KEY catid (CategoryId)
        )",
        
        "tbladmin" => "CREATE TABLE tbladmin (
            id int(11) NOT NULL AUTO_INCREMENT,
            AdminUserName varchar(255) DEFAULT NULL,
            AdminPassword varchar(255) DEFAULT NULL,
            AdminEmailId varchar(255) DEFAULT NULL,
            userType int(11) DEFAULT NULL,
            CreationDate timestamp NOT NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            PRIMARY KEY (id),
            KEY AdminUserName (AdminUserName)
        )",
        
        "tblposts" => "CREATE TABLE tblposts (
            id int(11) NOT NULL AUTO_INCREMENT,
            PostTitle longtext DEFAULT NULL,
            CategoryId int(11) DEFAULT NULL,
            SubCategoryId int(11) DEFAULT NULL,
            PostDetails longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT NULL,
            PostUrl mediumtext DEFAULT NULL,
            PostImage varchar(255) DEFAULT NULL,
            viewCounter int(11) DEFAULT NULL,
            postedBy varchar(255) DEFAULT NULL,
            lastUpdatedBy varchar(255) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY id (id),
            KEY postcatid (CategoryId),
            KEY postsucatid (SubCategoryId),
            KEY subadmin (postedBy)
        )",
        
        "tblcomments" => "CREATE TABLE tblcomments (
            id int(11) NOT NULL AUTO_INCREMENT,
            postId int(11) DEFAULT NULL,
            name varchar(120) DEFAULT NULL,
            email varchar(150) DEFAULT NULL,
            comment mediumtext DEFAULT NULL,
            postingDate timestamp NULL DEFAULT current_timestamp(),
            status int(1) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY id (id),
            KEY postId (postId)
        )",
        
        "tblpages" => "CREATE TABLE tblpages (
            id int(11) NOT NULL AUTO_INCREMENT,
            PageName varchar(200) DEFAULT NULL,
            PageTitle mediumtext DEFAULT NULL,
            Description longtext DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            PRIMARY KEY (id)
        )"
    ];
    
    foreach ($tables as $name => $sql) {
        if ($conn->query($sql) === TRUE) {
            echo "<p class='success'>✅ Table '$name' created</p>";
        } else {
            echo "<p class='error'>❌ Error creating table '$name': " . $conn->error . "</p>";
        }
    }
    
    // Insert sample data
    echo "<h3>📝 Inserting Sample Data...</h3>";
    
    $sampleData = [
        "INSERT INTO tblcategory (id, CategoryName, Description, PostingDate, UpdationDate, Is_Active) VALUES 
        (3, 'Sports', 'Related to sports news', '2024-01-11 18:30:00', '2024-01-31 05:43:16', 1),
        (5, 'Entertainment', 'Entertainment related News', '2024-01-11 18:30:00', '2024-01-31 05:43:25', 1),
        (6, 'Politics', 'Politics', '2024-01-11 18:30:00', '2024-01-31 05:43:25', 1),
        (7, 'Business', 'Business', '2024-01-11 18:30:00', '2024-01-31 05:43:25', 1),
        (8, 'Technology', 'Technology', '2024-01-11 18:30:00', '2024-01-31 05:43:25', 1)",
        
        "INSERT INTO tblsubcategory (SubCategoryId, CategoryId, Subcategory, SubCatDescription, PostingDate, UpdationDate, Is_Active) VALUES
        (3, 5, 'Bollywood', 'Bollywood masala', '2024-01-14 18:30:00', '2024-01-31 05:48:30', 1),
        (4, 3, 'Cricket', 'Cricket', '2024-01-14 18:30:00', '2024-01-31 05:48:39', 1),
        (5, 3, 'Football', 'Football', '2024-01-14 18:30:00', '2024-01-31 05:48:39', 1),
        (6, 5, 'Television', 'Television', '2024-01-14 18:30:00', '2024-01-31 05:48:39', 1),
        (7, 6, 'National', 'National', '2024-01-14 18:30:00', '2024-01-31 05:48:39', 1),
        (8, 6, 'International', 'International', '2024-01-14 18:30:00', '2024-01-31 05:48:39', 1),
        (9, 7, 'India', 'India', '2024-01-14 18:30:00', '2024-01-31 05:48:39', 1)",
        
        "INSERT INTO tbladmin (id, AdminUserName, AdminPassword, AdminEmailId, userType, CreationDate, UpdationDate) VALUES
        (1, 'admin', 'f925916e2754e5e03f75dd58a5733251', 'admin@24x7news.com', 1, '2024-01-09 18:30:00', '2024-01-31 05:42:52')",
        
        "INSERT INTO tblposts (id, PostTitle, CategoryId, SubCategoryId, PostDetails, PostingDate, UpdationDate, Is_Active, PostUrl, PostImage, viewCounter, postedBy, lastUpdatedBy) VALUES
        (1, 'Welcome to 24 X 7 News Portal', 3, 4, 'This is your first news article in the 24 X 7 News Portal. You can edit or delete this from the admin panel. Welcome to our modern news platform!', '2024-01-15 18:30:00', '2024-01-31 05:47:37', 1, 'welcome-to-24-x-7-news-portal', NULL, 0, 'admin', NULL),
        (2, 'Technology Innovation Breakthrough', 8, NULL, 'Latest breakthrough in technology sector with revolutionary innovations that will change the digital landscape.', '2024-01-16 18:30:00', '2024-01-31 05:47:46', 1, 'technology-innovation-breakthrough', NULL, 15, 'admin', NULL),
        (3, 'Sports Championship Finals', 3, 4, 'Exciting finals of the championship with record-breaking performances and thrilling matches.', '2024-01-17 18:30:00', '2024-01-31 05:47:55', 1, 'sports-championship-finals', NULL, 22, 'admin', NULL)",
        
        "INSERT INTO tblpages (id, PageName, PageTitle, Description, PostingDate, UpdationDate) VALUES
        (1, 'aboutus', 'About 24 X 7', 'Welcome to 24 X 7 News Portal - your trusted source for breaking news, in-depth analysis, and comprehensive coverage 24 hours a day, 7 days a week.', '2024-01-14 18:30:00', '2024-01-31 05:44:12'),
        (2, 'contactus', 'Contact Details', '<p><b>Address:</b> New Delhi, India</p><p><b>Phone:</b> +91-01234567890</p><p><b>Email:</b> info@24x7news.com</p>', '2024-01-15 18:30:00', '2024-01-31 05:44:24')"
    ];
    
    foreach ($sampleData as $sql) {
        if ($conn->query($sql) === TRUE) {
            echo "<p class='success'>✅ Sample data inserted</p>";
        } else {
            echo "<p class='warning'>⚠️ Sample data: " . $conn->error . "</p>";
        }
    }
    
    echo "<div style='background:#e8f5e8;padding:30px;border:3px solid #4caf50;border-radius:15px;margin:30px 0;text-align:center;'>";
    echo "<h2>🎉 Database Fixed Successfully!</h2>";
    echo "<h3>Admin Login Details:</h3>";
    echo "<p><strong>Username:</strong> <code style='background:#f5f5f5;padding:5px;'>admin</code></p>";
    echo "<p><strong>Password:</strong> <code style='background:#f5f5f5;padding:5px;'>Test@123</code></p>";
    echo "<br>";
    echo "<a href='index.php' style='background:#2563eb;color:white;padding:15px 30px;text-decoration:none;border-radius:8px;font-size:18px;margin:10px;display:inline-block;'>🏠 Go to Homepage</a>";
    echo "<a href='admin/' style='background:#059669;color:white;padding:15px 30px;text-decoration:none;border-radius:8px;font-size:18px;margin:10px;display:inline-block;'>👨‍💼 Admin Panel</a>";
    echo "</div>";
    
    $conn->close();
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "</body></html>";
?>