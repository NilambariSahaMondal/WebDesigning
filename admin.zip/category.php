<?php
// This page uses Bootstrap 5 modern design
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Categories - 24 X 7</title>
    <!-- Preload critical resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" as="style">
    
    <!-- Load stylesheets -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    
    <!-- Scroll Progress Bar Styles -->
    <style>
        .scroll-progress {
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            background: linear-gradient(90deg, #007bff, #0056b3);
            z-index: 9999;
            transition: width 0.1s ease-out;
            box-shadow: 0 2px 4px rgba(0, 123, 255, 0.3);
        }
    </style>
</head>
<body>
<!-- Scroll Progress Bar -->
<div class="scroll-progress" id="scrollProgress"></div>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.php">
      <i class="bi bi-newspaper me-2"></i>24 X 7
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="bi bi-house me-1"></i>Home
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about-us.php">
            <i class="bi bi-info-circle me-1"></i>About
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact-us.php">
            <i class="bi bi-envelope me-1"></i>Contact
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="category.php">
            <i class="bi bi-grid me-1"></i>Categories
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="search.php">
            <i class="bi bi-search me-1"></i>Search
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container my-5">
  <!-- Categories Header -->
  <div class="row justify-content-center mb-5">
    <div class="col-lg-8 text-center">
      <h1 class="display-5 fw-bold mb-3">
        <i class="bi bi-grid-3x3-gap text-primary me-2"></i>
        News Categories
      </h1>
      <p class="lead text-muted">Explore news by category to find exactly what interests you</p>
    </div>
  </div>

  <!-- Category Grid -->
  <div class="row g-4">
    <div class="col-md-6 col-lg-4">
      <div class="card category-card h-100">
        <div class="card-body text-center p-4">
          <div class="category-icon mb-3">
            <i class="bi bi-trophy display-4" style="color: #10b981;"></i>
          </div>
          <h4 class="card-title">Sports</h4>
          <p class="card-text text-muted">Latest sports news, match results, player updates, and championship coverage</p>
          <div class="mb-3">
            <span class="badge bg-success rounded-pill">24 Articles</span>
          </div>
          <a href="#" class="btn btn-outline-success">
            <i class="bi bi-arrow-right me-1"></i>Browse Sports
          </a>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-4">
      <div class="card category-card h-100">
        <div class="card-body text-center p-4">
          <div class="category-icon mb-3">
            <i class="bi bi-bank display-4" style="color: #ef4444;"></i>
          </div>
          <h4 class="card-title">Politics</h4>
          <p class="card-text text-muted">Political developments, government policies, elections, and international relations</p>
          <div class="mb-3">
            <span class="badge bg-danger rounded-pill">18 Articles</span>
          </div>
          <a href="#" class="btn btn-outline-danger">
            <i class="bi bi-arrow-right me-1"></i>Browse Politics
          </a>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-4">
      <div class="card category-card h-100">
        <div class="card-body text-center p-4">
          <div class="category-icon mb-3">
            <i class="bi bi-film display-4" style="color: #f59e0b;"></i>
          </div>
          <h4 class="card-title">Entertainment</h4>
          <p class="card-text text-muted">Celebrity news, movie releases, music industry updates, and entertainment events</p>
          <div class="mb-3">
            <span class="badge bg-warning rounded-pill">32 Articles</span>
          </div>
          <a href="#" class="btn btn-outline-warning">
            <i class="bi bi-arrow-right me-1"></i>Browse Entertainment
          </a>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-4">
      <div class="card category-card h-100">
        <div class="card-body text-center p-4">
          <div class="category-icon mb-3">
            <i class="bi bi-graph-up display-4" style="color: #06b6d4;"></i>
          </div>
          <h4 class="card-title">Business</h4>
          <p class="card-text text-muted">Market analysis, corporate news, economic trends, and financial updates</p>
          <div class="mb-3">
            <span class="badge bg-info rounded-pill">15 Articles</span>
          </div>
          <a href="#" class="btn btn-outline-info">
            <i class="bi bi-arrow-right me-1"></i>Browse Business
          </a>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-4">
      <div class="card category-card h-100">
        <div class="card-body text-center p-4">
          <div class="category-icon mb-3">
            <i class="bi bi-cpu display-4" style="color: #8b5cf6;"></i>
          </div>
          <h4 class="card-title">Technology</h4>
          <p class="card-text text-muted">Tech innovations, gadget reviews, software updates, and digital trends</p>
          <div class="mb-3">
            <span class="badge bg-primary rounded-pill">21 Articles</span>
          </div>
          <a href="#" class="btn btn-outline-primary">
            <i class="bi bi-arrow-right me-1"></i>Browse Technology
          </a>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-4">
      <div class="card category-card h-100">
        <div class="card-body text-center p-4">
          <div class="category-icon mb-3">
            <i class="bi bi-heart-pulse display-4" style="color: #ec4899;"></i>
          </div>
          <h4 class="card-title">Health</h4>
          <p class="card-text text-muted">Medical breakthroughs, health tips, wellness trends, and healthcare news</p>
          <div class="mb-3">
            <span class="badge bg-secondary rounded-pill">12 Articles</span>
          </div>
          <a href="#" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-right me-1"></i>Browse Health
          </a>
        </div>
      </div>
    </div>
  </div>

  <!-- Quick Stats -->
  <div class="row mt-5">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <div class="row text-center">
            <div class="col-md-3">
              <div class="d-flex flex-column">
                <span class="display-6 fw-bold text-primary">122</span>
                <span class="text-muted">Total Articles</span>
              </div>
            </div>
            <div class="col-md-3">
              <div class="d-flex flex-column">
                <span class="display-6 fw-bold text-success">6</span>
                <span class="text-muted">Categories</span>
              </div>
            </div>
            <div class="col-md-3">
              <div class="d-flex flex-column">
                <span class="display-6 fw-bold text-warning">15</span>
                <span class="text-muted">Daily Updates</span>
              </div>
            </div>
            <div class="col-md-3">
              <div class="d-flex flex-column">
                <span class="display-6 fw-bold text-info">24/7</span>
                <span class="text-muted">Coverage</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bottom Social Media Share Section -->
<div class="container my-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-4">
          <h5 class="card-title mb-3">
            <i class="bi bi-share me-2"></i>Share This Page
          </h5>
          <p class="text-muted mb-4">Help others discover the latest news by sharing on social media</p>
          <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="#" class="btn btn-primary d-flex align-items-center" id="bottomShareFacebook" style="background: #1877f2; border-color: #1877f2;">
              <i class="bi bi-facebook me-2"></i>Share on Facebook
            </a>
            <a href="#" class="btn btn-info d-flex align-items-center" id="bottomShareTwitter" style="background: #1da1f2; border-color: #1da1f2;">
              <i class="bi bi-twitter me-2"></i>Share on Twitter
            </a>
            <a href="#" class="btn btn-success d-flex align-items-center" id="bottomShareWhatsApp" style="background: #25d366; border-color: #25d366;">
              <i class="bi bi-whatsapp me-2"></i>Share on WhatsApp
            </a>
            <button class="btn btn-secondary d-flex align-items-center" id="bottomPrintPage">
              <i class="bi bi-printer-fill me-2"></i>Print Page
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="footer mt-5">
  <div class="container">
    <p class="mb-0">&copy; 2025 24 X 7. All rights reserved.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Scroll Progress Bar Script -->
<script>
window.addEventListener('scroll', function() {
    const scrollProgress = document.getElementById('scrollProgress');
    const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrollPercentage = (scrollTop / scrollHeight) * 100;
    
    scrollProgress.style.width = scrollPercentage + '%';
});

// Bottom Social Media Share Functions
document.getElementById('bottomShareFacebook').addEventListener('click', function(e) {
    e.preventDefault();
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank', 'width=600,height=400');
});

document.getElementById('bottomShareTwitter').addEventListener('click', function(e) {
    e.preventDefault();
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    window.open(`https://twitter.com/intent/tweet?url=${url}&text=${title}`, '_blank', 'width=600,height=400');
});

document.getElementById('bottomShareWhatsApp').addEventListener('click', function(e) {
    e.preventDefault();
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    window.open(`https://wa.me/?text=${title} ${url}`, '_blank');
});

document.getElementById('bottomPrintPage').addEventListener('click', function() {
    window.print();
});
</script>
</body>
</html>