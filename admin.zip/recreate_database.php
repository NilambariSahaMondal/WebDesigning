<?php
// Quick database recreation for 24 X 7 News Portal
echo "<!DOCTYPE html><html><head><title>Recreate Database</title>";
echo "<style>body{font-family:Arial,sans-serif;max-width:600px;margin:50px auto;padding:20px;} .success{color:green;} .error{color:red;}</style>";
echo "</head><body>";
echo "<h1>🔄 Recreating 24 X 7 Database</h1>";

try {
    // Connect to MySQL without selecting database
    $conn = new mysqli('localhost', 'root', '');
    
    if ($conn->connect_error) {
        die("<p class='error'>❌ Connection failed: " . $conn->connect_error . "</p>");
    }
    
    echo "<p class='success'>✅ Connected to MySQL</p>";
    
    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS newsportal";
    if ($conn->query($sql) === TRUE) {
        echo "<p class='success'>✅ Database 'newsportal' created</p>";
    } else {
        echo "<p class='error'>❌ Error creating database: " . $conn->error . "</p>";
    }
    
    // Select database
    $conn->select_db("newsportal");
    
    // Create tables
    $tables = [
        "CREATE TABLE IF NOT EXISTS tblcategory (
            id int(11) NOT NULL AUTO_INCREMENT,
            CategoryName varchar(200) DEFAULT NULL,
            Description mediumtext DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT 1,
            PRIMARY KEY (id)
        )",
        
        "CREATE TABLE IF NOT EXISTS tblposts (
            id int(11) NOT NULL AUTO_INCREMENT,
            PostTitle longtext DEFAULT NULL,
            CategoryId int(11) DEFAULT NULL,
            SubCategoryId int(11) DEFAULT NULL,
            PostDetails longtext DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT 1,
            PostUrl mediumtext DEFAULT NULL,
            PostImage varchar(255) DEFAULT NULL,
            viewCounter int(11) DEFAULT 0,
            postedBy varchar(255) DEFAULT NULL,
            lastUpdatedBy varchar(255) DEFAULT NULL,
            PRIMARY KEY (id)
        )",
        
        "CREATE TABLE IF NOT EXISTS tbladmin (
            id int(11) NOT NULL AUTO_INCREMENT,
            AdminUserName varchar(255) DEFAULT NULL,
            AdminPassword varchar(255) DEFAULT NULL,
            AdminEmailId varchar(255) DEFAULT NULL,
            userType int(11) DEFAULT 1,
            CreationDate timestamp NOT NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            PRIMARY KEY (id)
        )",
        
        "CREATE TABLE IF NOT EXISTS tblsubcategory (
            SubCategoryId int(11) NOT NULL AUTO_INCREMENT,
            CategoryId int(11) DEFAULT NULL,
            Subcategory varchar(255) DEFAULT NULL,
            SubCatDescription mediumtext DEFAULT NULL,
            PostingDate timestamp NOT NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT 1,
            PRIMARY KEY (SubCategoryId)
        )",
        
        "CREATE TABLE IF NOT EXISTS tblcomments (
            id int(11) NOT NULL AUTO_INCREMENT,
            postId int(11) DEFAULT NULL,
            name varchar(120) DEFAULT NULL,
            email varchar(150) DEFAULT NULL,
            comment mediumtext DEFAULT NULL,
            postingDate timestamp NULL DEFAULT current_timestamp(),
            status int(1) DEFAULT NULL,
            PRIMARY KEY (id)
        )",
        
        "CREATE TABLE IF NOT EXISTS tblpages (
            id int(11) NOT NULL AUTO_INCREMENT,
            PageName varchar(200) DEFAULT NULL,
            PageTitle mediumtext DEFAULT NULL,
            Description longtext DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            PRIMARY KEY (id)
        )"
    ];
    
    foreach ($tables as $sql) {
        if ($conn->query($sql) === TRUE) {
            echo "<p class='success'>✅ Table created successfully</p>";
        } else {
            echo "<p class='error'>❌ Error creating table: " . $conn->error . "</p>";
        }
    }
    
    // Insert sample data
    $sampleData = [
        "INSERT IGNORE INTO tblcategory (id, CategoryName, Description, Is_Active) VALUES 
        (1, 'Sports', 'Sports news and updates', 1),
        (2, 'Politics', 'Political news and developments', 1),
        (3, 'Entertainment', 'Entertainment and celebrity news', 1),
        (4, 'Business', 'Business and economic news', 1),
        (5, 'Technology', 'Technology and innovation news', 1)",
        
        "INSERT IGNORE INTO tblsubcategory (SubCategoryId, CategoryId, Subcategory, SubCatDescription, Is_Active) VALUES 
        (1, 1, 'Cricket', 'Cricket news', 1),
        (2, 1, 'Football', 'Football news', 1),
        (3, 2, 'National', 'National politics', 1),
        (4, 2, 'International', 'International politics', 1)",
        
        "INSERT IGNORE INTO tbladmin (id, AdminUserName, AdminPassword, AdminEmailId, userType) VALUES 
        (1, 'admin', 'f925916e2754e5e03f75dd58a5733251', 'admin@24x7news.com', 1)",
        
        "INSERT IGNORE INTO tblposts (id, PostTitle, CategoryId, PostDetails, Is_Active, PostUrl, viewCounter) VALUES 
        (1, 'Welcome to 24 X 7 News Portal', 1, 'This is your first news article. You can edit or delete this from the admin panel.', 1, 'welcome-to-24-x-7-news-portal', 0),
        (2, 'Breaking: Technology Innovation', 5, 'Latest technology news and innovations in the digital world.', 1, 'breaking-technology-innovation', 5),
        (3, 'Sports Championship Update', 1, 'Latest updates from the sports championship with detailed coverage.', 1, 'sports-championship-update', 12)",
        
        "INSERT IGNORE INTO tblpages (id, PageName, PageTitle, Description) VALUES 
        (1, 'aboutus', 'About 24 X 7', 'Welcome to 24 X 7 News Portal - your trusted source for news 24 hours a day, 7 days a week.'),
        (2, 'contactus', 'Contact Details', 'Address: New Delhi, India<br>Phone: +91-01234567890<br>Email: info@24x7news.com')"
    ];
    
    foreach ($sampleData as $sql) {
        if ($conn->query($sql) === TRUE) {
            echo "<p class='success'>✅ Sample data inserted</p>";
        } else {
            echo "<p style='color:orange;'>⚠️ Sample data: " . $conn->error . "</p>";
        }
    }
    
    echo "<div style='background:#e8f5e8;padding:20px;border:2px solid #4caf50;border-radius:10px;margin:20px 0;text-align:center;'>";
    echo "<h2>🎉 Database Recreated Successfully!</h2>";
    echo "<p><strong>Admin Login:</strong></p>";
    echo "<p>Username: <code>admin</code></p>";
    echo "<p>Password: <code>Test@123</code></p>";
    echo "<br>";
    echo "<a href='index.php' style='background:#2563eb;color:white;padding:15px 30px;text-decoration:none;border-radius:8px;margin:10px;'>🏠 Homepage</a>";
    echo "<a href='admin/' style='background:#059669;color:white;padding:15px 30px;text-decoration:none;border-radius:8px;margin:10px;'>👨‍💼 Admin Panel</a>";
    echo "</div>";
    
    $conn->close();
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "</body></html>";
?>