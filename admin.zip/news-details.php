<?php
// This page uses Bootstrap 5 modern design
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Details - 24 X 7</title>
    <!-- Preload critical resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" as="style">
    
    <!-- Load stylesheets -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    
    <!-- Scroll Progress Bar Styles -->
    <style>
        .scroll-progress {
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            background: linear-gradient(90deg, #007bff, #0056b3);
            z-index: 9999;
            transition: width 0.1s ease-out;
            box-shadow: 0 2px 4px rgba(0, 123, 255, 0.3);
        }
    </style>
</head>
<body>
<!-- Scroll Progress Bar -->
<div class="scroll-progress" id="scrollProgress"></div>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.php">
      <i class="bi bi-newspaper me-2"></i>24 X 7
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="bi bi-house me-1"></i>Home
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about-us.php">
            <i class="bi bi-info-circle me-1"></i>About
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact-us.php">
            <i class="bi bi-envelope me-1"></i>Contact
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="category.php">
            <i class="bi bi-grid me-1"></i>Categories
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="search.php">
            <i class="bi bi-search me-1"></i>Search
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container my-4">
<h1 class='mb-4'>News Article Title</h1>
<div class="mb-4" style="height: 400px; background: linear-gradient(45deg, #2563eb, #1d4ed8); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-size: 28px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">
  <div class="text-center">
    <i class="bi bi-newspaper display-3 mb-3"></i>
    <div>NEWS ARTICLE</div>
    <small class="d-block mt-2" style="font-size: 16px;">24 X 7 Coverage</small>
  </div>
</div>
<p>This is a detailed news article with comprehensive coverage of the latest events. You can edit this content from the admin panel to add your own news stories and keep your readers informed with the latest updates.</p>
</div>

<!-- Bottom Social Media Share Section -->
<div class="container my-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-4">
          <h5 class="card-title mb-3">
            <i class="bi bi-share me-2"></i>Share This Article
          </h5>
          <p class="text-muted mb-4">Help others stay informed by sharing this news article</p>
          <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="#" class="btn btn-primary d-flex align-items-center" id="bottomShareFacebook" style="background: #1877f2; border-color: #1877f2;">
              <i class="bi bi-facebook me-2"></i>Share on Facebook
            </a>
            <a href="#" class="btn btn-info d-flex align-items-center" id="bottomShareTwitter" style="background: #1da1f2; border-color: #1da1f2;">
              <i class="bi bi-twitter me-2"></i>Share on Twitter
            </a>
            <a href="#" class="btn btn-success d-flex align-items-center" id="bottomShareWhatsApp" style="background: #25d366; border-color: #25d366;">
              <i class="bi bi-whatsapp me-2"></i>Share on WhatsApp
            </a>
            <button class="btn btn-secondary d-flex align-items-center" id="bottomPrintPage">
              <i class="bi bi-printer-fill me-2"></i>Print Article
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="footer mt-5">
  <div class="container">
    <p class="mb-0">&copy; 2025 24 X 7. All rights reserved.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Scroll Progress Bar Script -->
<script>
window.addEventListener('scroll', function() {
    const scrollProgress = document.getElementById('scrollProgress');
    const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrollPercentage = (scrollTop / scrollHeight) * 100;
    
    scrollProgress.style.width = scrollPercentage + '%';
});

// Bottom Social Media Share Functions
document.getElementById('bottomShareFacebook').addEventListener('click', function(e) {
    e.preventDefault();
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank', 'width=600,height=400');
});

document.getElementById('bottomShareTwitter').addEventListener('click', function(e) {
    e.preventDefault();
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    window.open(`https://twitter.com/intent/tweet?url=${url}&text=${title}`, '_blank', 'width=600,height=400');
});

document.getElementById('bottomShareWhatsApp').addEventListener('click', function(e) {
    e.preventDefault();
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(document.title);
    window.open(`https://wa.me/?text=${title} ${url}`, '_blank');
});

document.getElementById('bottomPrintPage').addEventListener('click', function() {
    window.print();
});
</script>
</body>
</html>
