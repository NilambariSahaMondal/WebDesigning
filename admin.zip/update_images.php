<?php
// Update index.php to use actual images instead of CSS gradients
echo "<h2>🔄 Updating 24 X 7 News Portal to Use Images</h2>";

// Read current index.php
$indexContent = file_get_contents('index.php');

if (!$indexContent) {
    die("<p style='color: red;'>❌ Could not read index.php</p>");
}

// Replace CSS gradient backgrounds with actual images
$replacements = [
    // Featured news image
    '<div class="card-img-top" style="height: 300px; background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 24px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
          <div class="text-center">
            <i class="bi bi-newspaper display-4 mb-2"></i>
            <div>Breaking News</div>
          </div>
        </div>' => '<img src="images/breaking-news.jpg" class="card-img-top" alt="Breaking News" style="height: 300px; object-fit: cover;" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';">
        <div class="card-img-top" style="height: 300px; background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); display: none; align-items: center; justify-content: center; color: white; font-size: 24px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
          <div class="text-center">
            <i class="bi bi-newspaper display-4 mb-2"></i>
            <div>Breaking News</div>
          </div>
        </div>',
    
    // Sports image
    '<div class="card-img-top" style="height: 150px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 18px; font-weight: bold; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">
              <div class="text-center">
                <i class="bi bi-trophy display-6 mb-1"></i>
                <div>Sports</div>
              </div>
            </div>' => '<img src="images/sports-news.jpg" class="card-img-top" alt="Sports News" style="height: 150px; object-fit: cover;" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';">
            <div class="card-img-top" style="height: 150px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); display: none; align-items: center; justify-content: center; color: white; font-size: 18px; font-weight: bold; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">
              <div class="text-center">
                <i class="bi bi-trophy display-6 mb-1"></i>
                <div>Sports</div>
              </div>
            </div>',
    
    // Technology image
    '<div class="card-img-top" style="height: 150px; background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 18px; font-weight: bold; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">
              <div class="text-center">
                <i class="bi bi-cpu display-6 mb-1"></i>
                <div>Technology</div>
              </div>
            </div>' => '<img src="images/tech-news.jpg" class="card-img-top" alt="Technology News" style="height: 150px; object-fit: cover;" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';">
            <div class="card-img-top" style="height: 150px; background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); display: none; align-items: center; justify-content: center; color: white; font-size: 18px; font-weight: bold; text-shadow: 1px 1px 2px rgba(0,0,0,0.3);">
              <div class="text-center">
                <i class="bi bi-cpu display-6 mb-1"></i>
                <div>Technology</div>
              </div>
            </div>',
    
    // Politics image
    '<div class="card-img-top" style="height: 200px; background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 20px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
          <div class="text-center">
            <i class="bi bi-bank display-5 mb-2"></i>
            <div>Politics</div>
          </div>
        </div>' => '<img src="images/politics-news.jpg" class="card-img-top" alt="Politics News" style="height: 200px; object-fit: cover;" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';">
        <div class="card-img-top" style="height: 200px; background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); display: none; align-items: center; justify-content: center; color: white; font-size: 20px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
          <div class="text-center">
            <i class="bi bi-bank display-5 mb-2"></i>
            <div>Politics</div>
          </div>
        </div>',
    
    // Business image
    '<div class="card-img-top" style="height: 200px; background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 20px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
          <div class="text-center">
            <i class="bi bi-graph-up display-5 mb-2"></i>
            <div>Business</div>
          </div>
        </div>' => '<img src="images/business-news.jpg" class="card-img-top" alt="Business News" style="height: 200px; object-fit: cover;" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';">
        <div class="card-img-top" style="height: 200px; background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%); display: none; align-items: center; justify-content: center; color: white; font-size: 20px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
          <div class="text-center">
            <i class="bi bi-graph-up display-5 mb-2"></i>
            <div>Business</div>
          </div>
        </div>',
    
    // Entertainment image
    '<div class="card-img-top" style="height: 200px; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 20px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
          <div class="text-center">
            <i class="bi bi-film display-5 mb-2"></i>
            <div>Entertainment</div>
          </div>
        </div>' => '<img src="images/entertainment-news.jpg" class="card-img-top" alt="Entertainment News" style="height: 200px; object-fit: cover;" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';">
        <div class="card-img-top" style="height: 200px; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); display: none; align-items: center; justify-content: center; color: white; font-size: 20px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
          <div class="text-center">
            <i class="bi bi-film display-5 mb-2"></i>
            <div>Entertainment</div>
          </div>
        </div>'
];

// Apply replacements
$updatedContent = $indexContent;
$replacementCount = 0;

foreach ($replacements as $search => $replace) {
    if (strpos($updatedContent, $search) !== false) {
        $updatedContent = str_replace($search, $replace, $updatedContent);
        $replacementCount++;
        echo "<p style='color: green;'>✅ Updated image section</p>";
    }
}

// Save updated content
if (file_put_contents('index.php', $updatedContent)) {
    echo "<h3 style='color: green;'>🎉 Successfully updated $replacementCount image sections!</h3>";
    echo "<p><strong>Features added:</strong></p>";
    echo "<ul>";
    echo "<li>✅ Real images will show when available</li>";
    echo "<li>✅ Gradient fallbacks if images fail to load</li>";
    echo "<li>✅ Smooth error handling</li>";
    echo "</ul>";
    echo "<p><a href='index.php' style='background: #2563eb; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-size: 18px;'>🏠 View Updated Homepage</a></p>";
} else {
    echo "<p style='color: red;'>❌ Failed to update index.php</p>";
}
?>