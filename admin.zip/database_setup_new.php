<?php
// 24 X 7 News Portal - Advanced Database Setup
echo "<!DOCTYPE html><html><head><title>24 X 7 Database Setup</title>";
echo "<style>body{font-family:Arial,sans-serif;max-width:800px;margin:50px auto;padding:20px;} .success{color:green;} .error{color:red;} .warning{color:orange;} .info{background:#e3f2fd;padding:15px;border-radius:5px;margin:10px 0;}</style>";
echo "</head><body>";
echo "<h1>🚀 24 X 7 News Portal - Database Setup</h1>";

// Try different MySQL configurations
$configs = [
    ['host' => 'localhost', 'user' => 'root', 'pass' => '', 'port' => 3306],
    ['host' => '127.0.0.1', 'user' => 'root', 'pass' => '', 'port' => 3306],
    ['host' => 'localhost', 'user' => 'root', 'pass' => 'root', 'port' => 3306],
    ['host' => 'localhost', 'user' => 'root', 'pass' => 'mysql', 'port' => 3306],
    ['host' => 'localhost', 'user' => 'root', 'pass' => '', 'port' => 3307]
];

$conn = null;
$working_config = null;

echo "<div class='info'><h3>🔍 Testing MySQL Connections...</h3></div>";

foreach ($configs as $i => $config) {
    echo "<p><strong>Test " . ($i + 1) . ":</strong> {$config['user']}@{$config['host']}:{$config['port']} ";
    echo "Password: " . ($config['pass'] ? 'YES' : 'NO') . "</p>";
    
    try {
        // Try connection
        $test_conn = new mysqli($config['host'], $config['user'], $config['pass'], '', $config['port']);
        
        if (!$test_conn->connect_error) {
            echo "<p class='success'>✅ SUCCESS! Connected to MySQL</p>";
            $conn = $test_conn;
            $working_config = $config;
            break;
        } else {
            echo "<p class='warning'>❌ Failed: " . $test_conn->connect_error . "</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Exception: " . $e->getMessage() . "</p>";
    }
    echo "<hr>";
}

if (!$conn || $conn->connect_error) {
    echo "<div style='background:#ffebee;padding:20px;border:2px solid #f44336;border-radius:10px;margin:20px 0;'>";
    echo "<h2>🚨 MySQL Connection Failed</h2>";
    echo "<p><strong>Quick Fix Options:</strong></p>";
    echo "<h3>Option 1: XAMPP Control Panel Fix</h3>";
    echo "<ol>";
    echo "<li>Open XAMPP Control Panel as Administrator</li>";
    echo "<li>Stop MySQL (click Stop button)</li>";
    echo "<li>Click 'Config' next to MySQL → select 'my.ini'</li>";
    echo "<li>Find <code>[mysqld]</code> section</li>";
    echo "<li>Add this line: <code>skip-grant-tables</code></li>";
    echo "<li>Save file and restart MySQL</li>";
    echo "<li>Refresh this page</li>";
    echo "</ol>";
    
    echo "<h3>Option 2: XAMPP Shell Method</h3>";
    echo "<ol>";
    echo "<li>In XAMPP Control Panel, click 'Shell'</li>";
    echo "<li>Type: <code>mysql -u root</code></li>";
    echo "<li>Type: <code>ALTER USER 'root'@'localhost' IDENTIFIED BY '';</code></li>";
    echo "<li>Type: <code>FLUSH PRIVILEGES;</code></li>";
    echo "<li>Type: <code>EXIT;</code></li>";
    echo "<li>Restart MySQL and refresh this page</li>";
    echo "</ol>";
    
    echo "<h3>Option 3: Use Different Server</h3>";
    echo "<p>If you have WAMP or another MySQL server running, you might need to:</p>";
    echo "<ul><li>Stop other MySQL services</li><li>Use different ports</li><li>Check Windows Services</li></ul>";
    echo "</div>";
    exit;
}

// If we get here, connection worked!
echo "<div style='background:#e8f5e8;padding:20px;border:2px solid #4caf50;border-radius:10px;margin:20px 0;'>";
echo "<h2>🎉 MySQL Connection Successful!</h2>";
echo "<p>Using: <strong>{$working_config['user']}@{$working_config['host']}:{$working_config['port']}</strong></p>";
echo "</div>";

try {
    // Create database
    echo "<h3>📁 Creating Database...</h3>";
    $sql = "CREATE DATABASE IF NOT EXISTS newsportal";
    if ($conn->query($sql) === TRUE) {
        echo "<p class='success'>✅ Database 'newsportal' created successfully!</p>";
    } else {
        echo "<p class='error'>❌ Error creating database: " . $conn->error . "</p>";
    }
    
    // Select database
    $conn->select_db("newsportal");
    
    // Create tables
    echo "<h3>🗂️ Creating Tables...</h3>";
    
    $tables = [
        "tblcategory" => "CREATE TABLE IF NOT EXISTS tblcategory (
            id int(11) NOT NULL AUTO_INCREMENT,
            CategoryName varchar(200) DEFAULT NULL,
            Description mediumtext DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT 1,
            PRIMARY KEY (id)
        )",
        
        "tblposts" => "CREATE TABLE IF NOT EXISTS tblposts (
            id int(11) NOT NULL AUTO_INCREMENT,
            PostTitle longtext DEFAULT NULL,
            CategoryId int(11) DEFAULT NULL,
            PostDetails longtext DEFAULT NULL,
            PostingDate timestamp NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            Is_Active int(1) DEFAULT 1,
            PostUrl mediumtext DEFAULT NULL,
            PostImage varchar(255) DEFAULT NULL,
            viewCounter int(11) DEFAULT 0,
            PRIMARY KEY (id)
        )",
        
        "tbladmin" => "CREATE TABLE IF NOT EXISTS tbladmin (
            id int(11) NOT NULL AUTO_INCREMENT,
            AdminUserName varchar(255) DEFAULT NULL,
            AdminPassword varchar(255) DEFAULT NULL,
            AdminEmailId varchar(255) DEFAULT NULL,
            userType int(11) DEFAULT 1,
            CreationDate timestamp NOT NULL DEFAULT current_timestamp(),
            UpdationDate timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
            PRIMARY KEY (id)
        )"
    ];
    
    foreach ($tables as $name => $sql) {
        if ($conn->query($sql) === TRUE) {
            echo "<p class='success'>✅ Table '$name' created successfully!</p>";
        } else {
            echo "<p class='error'>❌ Error creating table '$name': " . $conn->error . "</p>";
        }
    }
    
    // Insert sample data
    echo "<h3>📝 Inserting Sample Data...</h3>";
    
    $sampleData = [
        "INSERT IGNORE INTO tblcategory (id, CategoryName, Description, Is_Active) VALUES 
        (1, 'Sports', 'Sports news and updates', 1),
        (2, 'Politics', 'Political news and developments', 1),
        (3, 'Entertainment', 'Entertainment and celebrity news', 1),
        (4, 'Business', 'Business and economic news', 1),
        (5, 'Technology', 'Technology and innovation news', 1)",
        
        "INSERT IGNORE INTO tbladmin (id, AdminUserName, AdminPassword, AdminEmailId, userType) VALUES 
        (1, 'admin', 'f925916e2754e5e03f75dd58a5733251', 'admin@24x7news.com', 1)",
        
        "INSERT IGNORE INTO tblposts (id, PostTitle, CategoryId, PostDetails, Is_Active, PostUrl, viewCounter) VALUES 
        (1, 'Welcome to 24 X 7 News Portal', 1, 'This is your first news article. You can edit or delete this from the admin panel. Welcome to the modern news portal with beautiful design and responsive layout.', 1, 'welcome-to-24-x-7-news-portal', 0),
        (2, 'Breaking: Technology Innovation', 5, 'Latest technology news and innovations in the digital world.', 1, 'breaking-technology-innovation', 5),
        (3, 'Sports Championship Update', 1, 'Latest updates from the sports championship with detailed coverage.', 1, 'sports-championship-update', 12)"
    ];
    
    foreach ($sampleData as $sql) {
        if ($conn->query($sql) === TRUE) {
            echo "<p class='success'>✅ Sample data inserted!</p>";
        } else {
            echo "<p class='warning'>⚠️ Sample data: " . $conn->error . "</p>";
        }
    }
    
    // Update config.php
    echo "<h3>⚙️ Updating Configuration...</h3>";
    $config_content = "<?php
define('DB_SERVER','{$working_config['host']}');
define('DB_USER','{$working_config['user']}');
define('DB_PASS','{$working_config['pass']}');
define('DB_NAME','newsportal');
\$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno())
{
 echo \"Failed to connect to MySQL: \" . mysqli_connect_error();
}
?>";
    
    if (file_put_contents('includes/config.php', $config_content)) {
        echo "<p class='success'>✅ Database configuration updated!</p>";
    } else {
        echo "<p class='error'>❌ Could not update config file</p>";
    }
    
    echo "<div style='background:#e8f5e8;padding:30px;border:3px solid #4caf50;border-radius:15px;margin:30px 0;text-align:center;'>";
    echo "<h2>🎉 Setup Complete!</h2>";
    echo "<h3>Admin Login Details:</h3>";
    echo "<p><strong>Username:</strong> <code style='background:#f5f5f5;padding:5px;'>admin</code></p>";
    echo "<p><strong>Password:</strong> <code style='background:#f5f5f5;padding:5px;'>Test@123</code></p>";
    echo "<br>";
    echo "<a href='index.php' style='background:#2563eb;color:white;padding:15px 30px;text-decoration:none;border-radius:8px;font-size:18px;margin:10px;display:inline-block;'>🏠 Go to Homepage</a>";
    echo "<a href='admin/' style='background:#059669;color:white;padding:15px 30px;text-decoration:none;border-radius:8px;font-size:18px;margin:10px;display:inline-block;'>👨‍💼 Admin Panel</a>";
    echo "</div>";
    
    $conn->close();
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "</body></html>";
?>