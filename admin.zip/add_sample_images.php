<?php
// Create sample images for 24 X 7 News Portal
echo "<h2>📸 Creating Sample Images for 24 X 7 News Portal</h2>";

// Create images directory if it doesn't exist
if (!file_exists('images')) {
    mkdir('images', 0777, true);
    echo "<p>✅ Created images directory</p>";
}

// Function to create a simple colored image with text
function createSampleImage($width, $height, $color, $text, $filename) {
    // Create image
    $image = imagecreate($width, $height);
    
    // Convert hex color to RGB
    $hex = str_replace('#', '', $color);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    // Allocate colors
    $bg_color = imagecolorallocate($image, $r, $g, $b);
    $text_color = imagecolorallocate($image, 255, 255, 255);
    $shadow_color = imagecolorallocate($image, 0, 0, 0);
    
    // Add text with shadow
    $font_size = $width > 600 ? 5 : 4;
    $text_x = ($width - strlen($text) * imagefontwidth($font_size)) / 2;
    $text_y = ($height - imagefontheight($font_size)) / 2;
    
    // Shadow
    imagestring($image, $font_size, $text_x + 2, $text_y + 2, $text, $shadow_color);
    // Main text
    imagestring($image, $font_size, $text_x, $text_y, $text, $text_color);
    
    // Save image
    imagejpeg($image, "images/$filename", 90);
    imagedestroy($image);
    
    return file_exists("images/$filename");
}

// Create sample images
$images = [
    ['breaking-news.jpg', 800, 300, '#2563eb', 'BREAKING NEWS - 24 X 7'],
    ['sports-news.jpg', 400, 150, '#10b981', 'SPORTS UPDATE'],
    ['tech-news.jpg', 400, 150, '#8b5cf6', 'TECHNOLOGY'],
    ['politics-news.jpg', 400, 200, '#ef4444', 'POLITICS'],
    ['business-news.jpg', 400, 200, '#06b6d4', 'BUSINESS'],
    ['entertainment-news.jpg', 400, 200, '#f59e0b', 'ENTERTAINMENT']
];

$success_count = 0;
foreach ($images as $img) {
    if (createSampleImage($img[1], $img[2], $img[3], $img[4], $img[0])) {
        echo "<p style='color: green;'>✅ Created {$img[0]} ({$img[1]}x{$img[2]})</p>";
        $success_count++;
    } else {
        echo "<p style='color: red;'>❌ Failed to create {$img[0]}</p>";
    }
}

echo "<h3>🎉 Created $success_count sample images!</h3>";
echo "<p><a href='update_images.php' style='background: #2563eb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>📝 Update HTML to Use Images</a></p>";
echo "<p><a href='index.php' style='background: #059669; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>🏠 View Homepage</a></p>";
?>